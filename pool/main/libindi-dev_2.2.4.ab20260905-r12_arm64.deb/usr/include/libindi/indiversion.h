/* Set INDI Library version */
#define INDI_VERSION_MAJOR   2
#define INDI_VERSION_MINOR   2
#define INDI_VERSION_RELEASE 4
#define INDI_VERSION "2.2.4"

/* Define INDI Data Dir */
#define DATA_INSTALL_DIR "/usr/share/indi/"
